public interface TableListener {
    void alarm();
}
