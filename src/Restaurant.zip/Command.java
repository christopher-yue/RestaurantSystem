public interface Command {
    String execute();
}
