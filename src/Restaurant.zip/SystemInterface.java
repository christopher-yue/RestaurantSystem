public class SystemInterface {

    // display menu
    public void displayMenu() {
        System.out.println("Display menu");
    }

    // submit order
    public void submitOrder() {
        System.out.println("Submit order");
    }

    // display tab
    public void displayTab() {
        System.out.println("Display tab");
    }
}
