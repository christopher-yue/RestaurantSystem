public class OrderItem {
    private int itemNumber;

    // Constructor
    public OrderItem(int itemNumber) {
        this.itemNumber = itemNumber;
    }

    // Get order item number
    public int getItemNumber() {
        return itemNumber;
    }
}
